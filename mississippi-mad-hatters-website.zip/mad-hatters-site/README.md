# Liam Toohey and the Mississippi Mad Hatters — Band Website

A mobile-friendly, static, free-to-host band website. No paid services, database, build tools, or account required to edit locally.

## Preview
Open `index.html` in a browser. Fonts load from Google Fonts when connected; fallback fonts work offline.

## Publish for free (GitHub Pages)
1. Create a free account at https://github.com.
2. Create a new **public** repository, e.g. `mississippi-mad-hatters`.
3. Upload `index.html`, `styles.css`, and `script.js` to the repository root and commit.
4. Go to **Settings → Pages → Build and deployment**, select **Deploy from a branch**, choose `main` and `/ (root)`, and save.
5. Your site will appear at `https://YOUR-USERNAME.github.io/mississippi-mad-hatters/` after deployment. The site URL depends on your actual username and repository name.

## Before publishing
- Replace `YOUR-BOOKING-EMAIL@example.com` in `index.html` with your real booking email, including in the `mailto:` link. The current button is a placeholder and will not reach your band.
- Update the About text to your band's actual story.
- Add real show entries to the `SHOWS` array in `script.js` (format shown there).
- Replace Music placeholders with real video embeds or links.
- Replace photo placeholders with `<img src="images/your-photo.jpg" alt="Descriptive photo text">` and add the photos under an `images/` folder. Use images you own or have permission to use.
- Add your social media links when ready.
- Replace the decorative spade poster with your official logo if desired.

No show dates, contact details, music links, or photos have been invented. The website intentionally labels unfinished areas as coming soon.
